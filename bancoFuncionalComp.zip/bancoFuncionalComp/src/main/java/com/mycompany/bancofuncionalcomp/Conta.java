/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bancofuncionalcomp;

/**
 *
 * @author alunodev13
 */
public class Conta{
    private String numeroConta;
    private double saldo;
    private Titular t1 = new Titular();
    private Notificador n1 = new Notificador();

    public Conta() {
    }
       
    public Conta(int numero, String titular, String notif) {
    
    }

    public void depositar(double valor){
    
    }
    
    public boolean sacar(double valor){
        return true;
    }

    public String getNumeroConta() {
        return numeroConta;
    }

    public double getSaldo() {
        return saldo;
    }

    public Titular getT1() {
        return t1;
    }
    
    public void exibir(){
    
    }
    
    public void consultarSaldo(){
        Notificador n1 = new Notificador();
    }
}
