/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bancofuncionalcomp;

/**
 *
 * @author alunodev13
 */
public class ContaPoupança extends Conta{
    private double taxaJuros;
    private int diaAniversario;

    public ContaPoupança() {
    }

    public ContaPoupança(int numero, String titular, String notif, double taxa){
    
    }

    public double getTaxaJuros() {
        return taxaJuros;
    }

    public void setTaxaJuros(double taxaJuros) {
        this.taxaJuros = taxaJuros;
    }
    
    public void renderJuros(){
    
    }

    public int getDiaAniversario() {
        return diaAniversario;
    }
    
    public boolean sacar(double valor){
        return true;
    }
    
    public void exibir(){
    
    }
    
}
