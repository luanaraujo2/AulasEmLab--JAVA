/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bancofuncionalcomp;

/**
 *
 * @author alunodev13
 */
public class Notificador {
    private String canal;

    public Notificador() {
    }

    public Notificador(String canal) {
        this.canal = canal;
    }

    public String getCanal() {
        return canal;
    }
    
    public void enviarSaldo(String titular, double saldo){
        
    }
    
    public void enviarAlerta(String titular, String msg){
    
    }
}
