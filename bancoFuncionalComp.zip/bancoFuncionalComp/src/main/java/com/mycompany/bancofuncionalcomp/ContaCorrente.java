/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bancofuncionalcomp;

/**
 *
 * @author alunodev13
 */
public class ContaCorrente extends Conta{
    private double limite ;
    private int diaVencimento ;

    public ContaCorrente() {
    
    }
    
    public ContaCorrente(int numero, String titular, String notif, double limite) {
    
    }

    public double getLimite() {
        return limite;
    }

    public void setLimite(double limite) {
        this.limite = limite;
    }
    
    public boolean sacarComLimite(){
        return true;
    }
    
    public void cobrarTarifa(){
    }
    
    public void exibir(){
    
    }
}
