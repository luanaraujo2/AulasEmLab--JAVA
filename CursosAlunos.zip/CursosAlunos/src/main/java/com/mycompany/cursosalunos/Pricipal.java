/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.cursosalunos;
import javax.swing.JOptionPane;
/**
 *
 * @author alunolab13
 */
public class Pricipal {

    public static void main(String[] args) {
        String nomeAluno;
        int matricula;
        String codigo;
        String nome;
        nomeAluno = JOptionPane.showInputDialog("Escreva o primeiro nome do aluno 1: ");
        matricula = Integer.parseInt(JOptionPane.showInputDialog("Digite a matricula do aluno 1: "));
        codigo = JOptionPane.showInputDialog("Escreva o codigo 1: ");
        nome = JOptionPane.showInputDialog("Escreva o nome do curso do aluno 1: ");
        
        JOptionPane.showMessageDialog(null, "Informações do aluno 1: \nNome: " + nomeAluno + " \nMatricula: " + matricula + "\nCodigo: " + codigo + "\nCurso do aluno: " + nome);
    }
}
