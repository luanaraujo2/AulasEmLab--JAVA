/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bancocomp;

import java.util.ArrayList;
import java.util.List;

public class Conta {
    private double saldo, limite;
    private int agencia, numero;
    private List<String> transacoes;

    public Conta(int agencia, int numero, double saldo, double limite) {
        this.saldo = saldo;
        this.limite = limite;
        this.agencia = agencia;
        this.numero = numero;
        this.transacoes = new ArrayList<>();
        transacoes.add(String.format("Conta criada | Saldo: R$ %.2f | Limite: R$ %.2f | Saldo Disponível: R$ %.2f",
                saldo, limite, getSaldoDisponivel()));
    }

    public double getSaldoDisponivel() {
        return saldo + limite;
    }

    public double getSaldo() {
        return saldo;
    }

    public double getLimite() {
        return limite;
    }

    public void setLimite(double limite) {
        this.limite = limite;
    }

    public int getAgencia() {
        return agencia;
    }

    public void setAgencia(int agencia) {
        this.agencia = agencia;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public List<String> getTransacoes() {
        return transacoes;
    }

    public void creditar(double valor) {
        saldo += valor;
        transacoes.add(String.format("Crédito: +R$ %.2f | Saldo: R$ %.2f | Saldo Disponível: R$ %.2f",
                valor, saldo, getSaldoDisponivel()));
    }

    public boolean debitar(double valor) {
        if (valor <= getSaldoDisponivel()) {
            saldo -= valor;
            transacoes.add(String.format("Débito: -R$ %.2f | Saldo: R$ %.2f | Saldo Disponível: R$ %.2f",
                    valor, saldo, getSaldoDisponivel()));
            return true;
        } else {
            transacoes.add(String.format("Débito NEGADO (saldo insuficiente): R$ %.2f | Saldo: R$ %.2f | Saldo Disponível: R$ %.2f",
                    valor, saldo, getSaldoDisponivel()));
            return false;
        }
    }

    public boolean transferir(Conta destino, double valor) {
        if (valor <= getSaldoDisponivel()) {
            saldo -= valor;
            transacoes.add(String.format(
                    "Transferência enviada para Ag.%d C.%d: -R$ %.2f | Saldo: R$ %.2f | Saldo Disponível: R$ %.2f",
                    destino.getAgencia(), destino.getNumero(), valor, saldo, getSaldoDisponivel()));

            destino.saldo += valor;
            destino.transacoes.add(String.format(
                    "Transferência recebida de Ag.%d C.%d: +R$ %.2f | Saldo: R$ %.2f | Saldo Disponível: R$ %.2f",
                    agencia, numero, valor, destino.saldo, destino.getSaldoDisponivel()));

            return true;
        } else {
            transacoes.add(String.format(
                    "Transferência NEGADA para Ag.%d C.%d: R$ %.2f | Saldo: R$ %.2f | Saldo Disponível: R$ %.2f",
                    destino.getAgencia(), destino.getNumero(), valor, saldo, getSaldoDisponivel()));
            return false;
        }
    }

    @Override
    public String toString() {
        return "Ag: " + agencia + " | Conta: " + numero;
    }
}

