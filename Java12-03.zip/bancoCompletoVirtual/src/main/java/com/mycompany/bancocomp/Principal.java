/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bancocomp;

import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.List;

public class Principal {

    static List<Conta> contas = new ArrayList<>();

    public static void main(String[] args) {
        int opcao;
        do {
            String menu = "=== BANCO ===\n"
                    + "1 - Criar conta\n"
                    + "2 - Creditar\n"
                    + "3 - Debitar\n"
                    + "4 - Transferir\n"
                    + "5 - Consultar saldo\n"
                    + "6 - Relatório de transações\n"
                    + "0 - Sair";

            String input = JOptionPane.showInputDialog(null, menu, "Menu Principal", JOptionPane.PLAIN_MESSAGE);

            if (input == null) break;

            try {
                opcao = Integer.parseInt(input.trim());
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Opção inválida!");
                opcao = -1;
                continue;
            }

            switch (opcao) {
                case 1 -> criarConta();
                case 2 -> creditar();
                case 3 -> debitar();
                case 4 -> transferir();
                case 5 -> consultarSaldo();
                case 6 -> relatorio();
                case 0 -> JOptionPane.showMessageDialog(null, "Encerrando o sistema. Até logo!");
                default -> JOptionPane.showMessageDialog(null, "Opção inválida!");
            }
        } while (true);
    }

    static void criarConta() {
        try {
            int agencia = Integer.parseInt(JOptionPane.showInputDialog("Agência:"));
            int numero = Integer.parseInt(JOptionPane.showInputDialog("Número da conta:"));
            double saldo = Double.parseDouble(JOptionPane.showInputDialog("Saldo inicial (R$):"));
            double limite = Double.parseDouble(JOptionPane.showInputDialog("Limite (R$):"));

            for (Conta c : contas) {
                if (c.getAgencia() == agencia && c.getNumero() == numero) {
                    JOptionPane.showMessageDialog(null, "Já existe uma conta com esses dados!");
                    return;
                }
            }

            contas.add(new Conta(agencia, numero, saldo, limite));
            JOptionPane.showMessageDialog(null, "Conta criada com sucesso!\nAg: " + agencia + " | Conta: " + numero);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Entrada inválida. Tente novamente.");
        }
    }

    static Conta selecionarConta(String titulo) {
        if (contas.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Nenhuma conta cadastrada.");
            return null;
        }
        String[] opcoes = contas.stream().map(Conta::toString).toArray(String[]::new);
        String escolha = (String) JOptionPane.showInputDialog(null, titulo, "Selecionar Conta",
                JOptionPane.PLAIN_MESSAGE, null, opcoes, opcoes[0]);
        if (escolha == null) return null;
        for (Conta c : contas) {
            if (c.toString().equals(escolha)) return c;
        }
        return null;
    }

    static void creditar() {
        Conta c = selecionarConta("Selecione a conta para crédito:");
        if (c == null) return;
        try {
            double valor = Double.parseDouble(JOptionPane.showInputDialog("Valor para creditar (R$):"));
            if (valor <= 0) { JOptionPane.showMessageDialog(null, "Valor deve ser positivo."); return; }
            c.creditar(valor);
            JOptionPane.showMessageDialog(null, String.format("Crédito realizado!\nSaldo: R$ %.2f | Saldo Disponível: R$ %.2f",
                    c.getSaldo(), c.getSaldoDisponivel()));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Entrada inválida.");
        }
    }

    static void debitar() {
        Conta c = selecionarConta("Selecione a conta para débito:");
        if (c == null) return;
        try {
            double valor = Double.parseDouble(JOptionPane.showInputDialog("Valor para debitar (R$):"));
            if (valor <= 0) { JOptionPane.showMessageDialog(null, "Valor deve ser positivo."); return; }
            boolean ok = c.debitar(valor);
            if (ok)
                JOptionPane.showMessageDialog(null, String.format("Débito realizado!\nSaldo: R$ %.2f | Saldo Disponível: R$ %.2f",
                        c.getSaldo(), c.getSaldoDisponivel()));
            else
                JOptionPane.showMessageDialog(null, String.format("Saldo insuficiente!\nSaldo: R$ %.2f | Saldo Disponível: R$ %.2f",
                        c.getSaldo(), c.getSaldoDisponivel()));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Entrada inválida.");
        }
    }

    static void transferir() {
        if (contas.size() < 2) {
            JOptionPane.showMessageDialog(null, "É necessário pelo menos 2 contas para transferir.");
            return;
        }
        Conta origem = selecionarConta("Selecione a conta de ORIGEM:");
        if (origem == null) return;
        Conta destino = selecionarConta("Selecione a conta de DESTINO:");
        if (destino == null) return;
        if (origem == destino) { JOptionPane.showMessageDialog(null, "Origem e destino não podem ser iguais."); return; }
        try {
            double valor = Double.parseDouble(JOptionPane.showInputDialog("Valor para transferir (R$):"));
            if (valor <= 0) { JOptionPane.showMessageDialog(null, "Valor deve ser positivo."); return; }
            boolean ok = origem.transferir(destino, valor);
            if (ok)
                JOptionPane.showMessageDialog(null, String.format(
                        "Transferência realizada!\n%s\nSaldo: R$ %.2f | Saldo Disponível: R$ %.2f",
                        origem, origem.getSaldo(), origem.getSaldoDisponivel()));
            else
                JOptionPane.showMessageDialog(null, String.format(
                        "Transferência não realizada. Saldo insuficiente!\n%s\nSaldo: R$ %.2f | Saldo Disponível: R$ %.2f",
                        origem, origem.getSaldo(), origem.getSaldoDisponivel()));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Entrada inválida.");
        }
    }

    static void consultarSaldo() {
        Conta c = selecionarConta("Selecione a conta:");
        if (c == null) return;
        JOptionPane.showMessageDialog(null, String.format(
                "=== SALDO ===\n%s\nSaldo: R$ %.2f\nLimite: R$ %.2f\nSaldo Disponível: R$ %.2f",
                c, c.getSaldo(), c.getLimite(), c.getSaldoDisponivel()));
    }

    static void relatorio() {
        Conta c = selecionarConta("Selecione a conta para ver o relatório:");
        if (c == null) return;
        StringBuilder sb = new StringBuilder("=== RELATÓRIO ===\n" + c + "\n\n");
        for (String t : c.getTransacoes()) {
            sb.append("• ").append(t).append("\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }
}

