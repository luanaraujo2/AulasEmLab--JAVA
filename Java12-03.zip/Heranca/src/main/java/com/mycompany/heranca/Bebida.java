/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.heranca;

/**
 *
 * @author alunodev13
 */
public class Bebida extends Produto{
    private int qtdEstoque;

    public Bebida() {
    }

    public Bebida(int qtdEstoque, int codigo, String nome, double valor) {
        super(codigo, nome, valor);
        this.qtdEstoque = qtdEstoque;
    }

    public int getQtdEstoque() {
        return qtdEstoque;
    }

    public void setQtdEstoque(int qtdEstoque) {
        this.qtdEstoque = qtdEstoque;
    }
    
    
    public void darEntrada(int qtd){
        this.qtdEstoque += qtd;
    }
    
    public void darBaixa(int qtd){
        if (qtd > this.qtdEstoque){
            System.out.println("Estoque Insuficiente. Qtd disponivel: " + this.qtdEstoque);
        }
        else this.qtdEstoque -= qtd;
    }
    
}
