/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.teste;
//import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author alunolab13
 */
public class Principal {

    public static void main(String[] args) {
        //Scanner sc = new Scanner(System.in);
        
       /**System.out.println("Digite o agencia da conta 1: ");
        int agencia = sc.nextInt();  primeiro modo **/
        int agencia = Integer.parseInt(JOptionPane.showInputDialog("Digite o agencia da conta 1: "));
        
        /**System.out.println("Digite o numero da conta 1: ");
        int numero = sc.nextInt(); **/
        int numero = Integer.parseInt(JOptionPane.showInputDialog("Digite o numero da conta 1: "));
        
        /**System.out.println("Digite o saldo inicial da conta 1: ");
        double saldo = sc.nextDouble();**/
        double saldo = Double.parseDouble(JOptionPane.showInputDialog("Digite o saldo da conta 1: "));
        
        /**System.out.println("Digite o limite da conta 1: ");
        double limite = sc.nextDouble();**/
        double limite = Double.parseDouble(JOptionPane.showInputDialog("Digite o limite da conta 1: "));
        
        Conta c1 = new Conta (agencia, numero, saldo, limite);
        
        int agencia2 = Integer.parseInt(JOptionPane.showInputDialog("Digite o agencia da conta 2: "));
        int numero2 = Integer.parseInt(JOptionPane.showInputDialog("Digite o numero da conta 2: "));
        double saldo2 = Double.parseDouble(JOptionPane.showInputDialog("Digite o saldo da conta 2: "));
        double limite2 = Double.parseDouble(JOptionPane.showInputDialog("Digite o limite da conta 2: "));
        // --c1.transferir(c2, 10000);
        Conta c2 = new Conta (agencia2, numero2, saldo2, limite2);
        
        
        do{
            int escolhaConta;
            escolhaConta = Integer.parseInt(JOptionPane.showInputDialog("Escolha a conta que "
                    + "deseja movimentar(1 ou 2):));
        }while(escolhaConta < 1 && escolhaConta > 2);
        
        int escolha;
        escolha = Integer.parseInt(JOptionPane.showInputDialog("MENU:\nEscolha o que deseja fazer:\n"
                + "1 - Debitar\n"
                + "2 - Creditar\n"
                + "3 - Tranferir\n"));
        
            if(escolhaConta == 1){
                c1.creditar(saldo2);
            }
            else if(escolha == 2){

            }
            else if (escolha == 3){

            }
            else {
                JOptionPane.showInputDialog("Escolha invalida.\n");
            }
        }while();
        
        // --JOptionPane.showInputDialog(null, c1.getSaldoDisponivel());
        //System.out.println(c1.getSaldoDisponivel());
        //System.out.println(c2.getSaldoDisponivel());
        
    }
}
